import {NgModule} from '@angular/core'
import {Routes,RouterModule,PreloadAllModules} from '@angular/router' 
import {AppComponent} from './app.component'

export const routes : Routes = [
    {path:'', redirectTo:'AppComponent', pathMatch:'full'},
    {
        path:'',
        children:[
            {path: 'employees',loadChildren:'./employee/employee.module#EmployeeModule'}
        ]
    }
      
];
@NgModule({
    imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
    exports: [RouterModule]
  })

  
  export class AppRoutingModule { }