import { NgModule } from "@angular/core";
import { EmployeeComponent } from "./employee.component";
import { EmployeeRoutingModule } from "./employee.routing.module";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import {TableModule} from 'primeng/table';
import {DialogModule} from 'primeng/dialog'
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import { EmployeeService } from "src/service/employee.service";
import { GetHeaders } from "src/service/option-header.service";
import {ReactiveFormsModule} from '@angular/forms';


@NgModule({
    imports:[
            FormsModule,
            EmployeeRoutingModule,
            CommonModule,
            TableModule,
            ReactiveFormsModule,
            ButtonModule,
            InputTextModule,
            DialogModule
        ],
    declarations:[EmployeeComponent],
    providers:[EmployeeService,GetHeaders]
})
export class EmployeeModule{

}