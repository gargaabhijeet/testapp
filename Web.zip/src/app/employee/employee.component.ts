import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../../../src/service/employee.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';


@Component({

    selector:'emp-root',
    templateUrl:'./employee.component.html'
})

export class EmployeeComponent implements OnInit{
    private _employeeService :EmployeeService;
    private employeeForm: FormGroup;
    constructor(private formBuilder: FormBuilder,private employeeService:EmployeeService){
        this._employeeService=employeeService;
        this.employeeForm=this.formBuilder.group({
            'firstName': ['', [Validators.required]],
            'middleName': ['', [Validators.required]],
            'lastName': ['', [Validators.required]],
            'addressId': ['', [Validators.required]],
            'phoneId': ['', [Validators.required]]
        });
    }
    Employees:any=[];
    employee:any={};
    selectedEmployee:any;
    newEmployee:boolean;
    displayDialog: boolean;
    
    employeeDetails={
        firstName:'',
        middleName:'',
        lastName:'',
        addressId:'',
        phoneId:''
    }
    ngOnInit(){
        this._employeeService.GetEmployees().subscribe(
            employees=>{
            this.Employees=employees,
            console.log(employees)
            }
        );
    }
    createNew(employeeForm:FormData){
        this.employeeDetails.firstName=this.employeeForm.controls['firstName'].value;
        this.employeeDetails.middleName=this.employeeForm.controls['middleName'].value;
        this.employeeDetails.lastName=this.employeeForm.controls['lastName'].value;
        this.employeeDetails.addressId=this.employeeForm.controls['addressId'].value;
        this.employeeDetails.phoneId=this.employeeForm.controls['phoneId'].value;
        this._employeeService.CreateEmployee(this.employeeDetails).subscribe(
            data => {
                console.log(data),
        err => console.log(err)}
        );
    }
    onRowSelect(event) {
        this.newEmployee = false;
        this.employee = this.cloneEmployee(event.data);
        this.displayDialog = true;
    }
    cloneEmployee(c: any): any {
        let employee = {};
        for (let prop in c) {
            employee[prop] = c[prop];
        }
        return employee;
    }
   
       
}