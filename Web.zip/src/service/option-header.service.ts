import { Headers, RequestOptions, Http } from "@angular/http";
import { Injectable } from "@angular/core";
import { HttpHeaders } from "@angular/common/http";

@Injectable()
export class GetHeaders {
  constructor() { }
  private headers: Headers = new Headers(
    {
      "Access-Control-Allow-Origin": "*",
      // "Content-Type": "application/json",
      "Access-Control-Allow-Methods": "*",
      "Access-Control-Allow-Headers": "Origin, Content-Type, X-Auth-Token",
      "Accept": "application/json",
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
      'Expires': 'Sat, 01 Jan 2000 00:00:00 GMT'
    });
  private httpheaders: HttpHeaders = new HttpHeaders(
    {
      "Access-Control-Allow-Origin": "*",
      //"Content-Type": "application/json",
      "Access-Control-Allow-Methods": "*",
      "Access-Control-Allow-Headers": "Origin, Content-Type, X-Auth-Token",
      "Accept": "application/json",
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
      'Expires': 'Sat, 01 Jan 2000 00:00:00 GMT'
    });
  get() {

    const options = new RequestOptions({ headers: this.headers, withCredentials: false });
    return options;
  }
  getHeader() {
    const options = { headers: this.httpheaders };
    return options;
  }
  getHttpHeaders() {
    return this.httpheaders;
  }
}
