
import { GetHeaders } from './option-header.service';
import { Observable, of, observable } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators'
import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders, HttpErrorResponse, HttpResponseBase } from '@angular/common/http';
import 'rxjs';
import { environment } from '../environments/environment';
import { Http, Response, Headers, ResponseContentType } from '@angular/http';

@Injectable()
export class EmployeeService {
  constructor(private http: HttpClient, private getHeader: GetHeaders) {
  }
  GetEmployees(): Observable<any> {
    return this.http.get(environment.APIEndpoint + "/api/Employee", { headers: this.getHeader.getHttpHeaders() })
      .pipe(tap((data) =>JSON.stringify(data)),
        catchError(this.handleError));
  }
  CreateEmployee(formData): Observable<any> {
    return this.http.post(environment.APIEndpoint + "/api/Employee", formData, { headers: this.getHeader.getHttpHeaders() })
      .pipe(map((data) => data),
        catchError(this.handleError));
  }
  // GetEmployees(): Observable<any> {
  //   return this.http.get(environment.APIEndpoint + "/api/Employee")
  //     .pipe(map((data) => data),
  //       catchError(this.handleError));
  // }
  private handleError(error: Response) {
    console.error(error);
    //this.loader.hide();
    return Observable.throw(error.json().error || 'Server error');
  }
}